package vip.hfybbs.fakewechat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    
}
